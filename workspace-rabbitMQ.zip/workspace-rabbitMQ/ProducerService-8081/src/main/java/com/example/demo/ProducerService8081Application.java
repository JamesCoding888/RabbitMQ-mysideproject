package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducerService8081Application {

	public static void main(String[] args) {
		SpringApplication.run(ProducerService8081Application.class, args);
	}

}
