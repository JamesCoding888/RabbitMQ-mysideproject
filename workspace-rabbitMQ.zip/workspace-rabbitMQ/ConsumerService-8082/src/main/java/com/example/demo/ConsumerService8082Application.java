package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumerService8082Application {

	public static void main(String[] args) {
		SpringApplication.run(ConsumerService8082Application.class, args);
	}

}
