package com.example.demo.service;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class ConsumerService {
	
	// Listener MyQueue
	@RabbitListener(queues = "MyQueue")
	public void consumerMessageFromQueue(String message) {
		System.out.println("Consume a message: " + message);
	}
}
